import 'package:flutter_dotenv/flutter_dotenv.dart';

class EnvConstants {
  const EnvConstants._();

  static String get supabaseUrl {
    return dotenv.env['SUPABASE_URL'] ?? '';
  }

  static String get supabasePublishableKey {
    return dotenv.env['SUPABASE_PUBLISHABLE_KEY'] ?? '';
  }

  static String get gNewsApiKey {
    return dotenv.env['GNEWS_API_KEY'] ?? '';
  }
}