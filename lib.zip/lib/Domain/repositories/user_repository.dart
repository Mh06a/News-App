import 'package:news_app/Domain/entities/user.dart';
import 'package:news_app/core/result/result.dart';

abstract class UserRepository {
  //step1 -->> create function to get profile:
  Future<Result<User>> getProfile();


  //step2 -->> create function to update profile :
  Future<Result<User>> updateProfile({
    required String name,
    String? location,
  });


  //step3 -->> create function to update user avatar :
  Future<Result<User>> updateAvatar({
    required String filePath,
  });


  //step4 -->> create function to delete account :
  Future<Result<void>> deleteAccount();


  //step5 -->> create function to get avatar path :
  Future<Result<String>> getAvatarUrl({
    required String avatarPath,
  });
}