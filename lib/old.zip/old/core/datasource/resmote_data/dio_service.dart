import 'package:dio/dio.dart';

import '../../constants/api_constants.dart';
import 'interceptors/api_key_interceptor.dart';
import 'interceptors/error_interceptor.dart';
import 'interceptors/logger_interceptor.dart';


class DioService {
  DioService._();

  static final DioService instance = DioService._();

  late final Dio dio =
      Dio(
          BaseOptions(
            baseUrl: ApiConstants.baseUrl,
            connectTimeout: const Duration(seconds: 10),
            receiveTimeout: const Duration(seconds: 10),
            responseType: ResponseType.json,
            headers: {Headers.acceptHeader: 'application/json'},
          ),
        )
        ..interceptors.add(ApiKeyInterceptor())
        ..interceptors.add(LoggerInterceptor())
        ..interceptors.add(ErrorInterceptor());
}
