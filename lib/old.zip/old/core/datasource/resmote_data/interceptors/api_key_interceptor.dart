import 'package:dio/dio.dart';

import '../../../constants/api_constants.dart';

class ApiKeyInterceptor extends Interceptor {
  @override
  void onRequest(RequestOptions options, RequestInterceptorHandler handler) {
    options.queryParameters["apiKey"] = ApiConstants.apiKey;

    handler.next(options);
  }
}
