import 'package:news_app/Data/models/user_model.dart';
import 'package:news_app/core/error/exceptions.dart';
import 'package:supabase_flutter/supabase_flutter.dart' as supabase;

abstract class SupabaseAuthDataSource {
  Future<UserModel> signUp({
    required String name,
    required String email,
    required String password,
  });

  Future<UserModel> signIn({
    required String email,
    required String password,
  });

  Future<UserModel> signInWithGoogle();

  Future<UserModel> signInWithApple();

  Future<UserModel?> getCurrentUser();

  Future<void> signOut();

  Future<void> resetPassword({
    required String email,
  });
}


class SupabaseAuthDataSourceImpl implements SupabaseAuthDataSource {
  // Step 1 -- Class variables
  final supabase.SupabaseClient supabaseClient;

  // Step 2 -- Constructor
  const SupabaseAuthDataSourceImpl({
    required this.supabaseClient,
  });

  // Step 3 -- Implement SupabaseAuthDataSource functions
  // Sign Up
  @override
  Future<UserModel> signUp({
    required String name,
    required String email,
    required String password,
  }) async {
    try {
      final response = await supabaseClient.auth.signUp(
        email: email,
        password: password,
        data: {
          'full_name': name,
        },
      );

      final user = response.user;

      if (user == null) {
        throw const AuthException(
          'Account could not be created.',
        );
      }

      return UserModel(
        id: user.id,
        name: name,
        email: user.email ?? email,
      );
    } on AuthException {
      rethrow;
    } on supabase.AuthException catch (e) {
      throw AuthException(e.message);
    } catch (e) {
      throw UnknownException(e.toString());
    }
  }

  // Sign In
  @override
  Future<UserModel> signIn({
    required String email,
    required String password,
  }) async {
    try {
      final response = await supabaseClient.auth.signInWithPassword(
        email: email,
        password: password,
      );

      final user = response.user;

      if (user == null) {
        throw const AuthException(
          'Invalid email or password.',
        );
      }

      return UserModel(
        id: user.id,
        name: user.userMetadata?['full_name'] as String? ??
            user.userMetadata?['name'] as String? ??
            '',
        email: user.email ?? email,
      );
    } on AuthException {
      rethrow;
    } on supabase.AuthException catch (e) {
      throw AuthException(e.message);
    } catch (e) {
      throw UnknownException(e.toString());
    }
  }

  // Sign In With Google
  @override
  Future<UserModel> signInWithGoogle() async {
    try {
      await supabaseClient.auth.signInWithOAuth(
        supabase.OAuthProvider.google,
        redirectTo: null,
      );

      final user = supabaseClient.auth.currentUser;

      if (user == null) {
        throw const AuthException(
          'Google sign in failed.',
        );
      }

      return UserModel(
        id: user.id,
        name: user.userMetadata?['full_name'] as String? ??
            user.userMetadata?['name'] as String? ??
            '',
        email: user.email ?? '',
      );
    } on AuthException {
      rethrow;
    } on supabase.AuthException catch (e) {
      throw AuthException(e.message);
    } catch (e) {
      throw UnknownException(e.toString());
    }
  }

  // Sign In With Apple
  @override
  Future<UserModel> signInWithApple() async {
    try {
      await supabaseClient.auth.signInWithOAuth(
        supabase.OAuthProvider.apple,
        redirectTo: null,
      );

      final user = supabaseClient.auth.currentUser;

      if (user == null) {
        throw const AuthException(
          'Apple sign in failed.',
        );
      }

      return UserModel(
        id: user.id,
        name: user.userMetadata?['full_name'] as String? ??
            user.userMetadata?['name'] as String? ??
            '',
        email: user.email ?? '',
      );
    } on AuthException {
      rethrow;
    } on supabase.AuthException catch (e) {
      throw AuthException(e.message);
    } catch (e) {
      throw UnknownException(e.toString());
    }
  }

  // Get Current User
  @override
  Future<UserModel?> getCurrentUser() async {
    try {
      final user = supabaseClient.auth.currentUser;

      if (user == null) {
        return null;
      }

      return UserModel(
        id: user.id,
        name: user.userMetadata?['full_name'] as String? ??
            user.userMetadata?['name'] as String? ??
            '',
        email: user.email ?? '',
      );
    } catch (e) {
      throw UnknownException(e.toString());
    }
  }

  // Sign Out
  @override
  Future<void> signOut() async {
    try {
      await supabaseClient.auth.signOut();
    } on supabase.AuthException catch (e) {
      throw AuthException(e.message);
    } catch (e) {
      throw UnknownException(e.toString());
    }
  }

  // Reset Password
  @override
  Future<void> resetPassword({
    required String email,
  }) async {
    try {
      await supabaseClient.auth.resetPasswordForEmail(
        email,
      );
    } on supabase.AuthException catch (e) {
      throw AuthException(e.message);
    } catch (e) {
      throw UnknownException(e.toString());
    }
  }
}